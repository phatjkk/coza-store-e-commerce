﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CozaStore.Areas.Private.Controllers
{
    public class CustomersInformationController : Controller
    {
        // GET: Private/CustomersInformation
        public ActionResult Index()
        {
            return View();
        }
    }
}